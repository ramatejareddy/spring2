package com.cg.movie.entity;

public enum BookingState {
	Available,
	Blocked,
	Booked
	

}
