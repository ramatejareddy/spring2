package com.cg.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringassginmentsLab41Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringassginmentsLab41Application.class, args);
	}

}
