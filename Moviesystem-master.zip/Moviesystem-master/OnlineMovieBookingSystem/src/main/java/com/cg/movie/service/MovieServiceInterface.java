package com.cg.movie.service;

import java.util.List;

import com.cg.movie.entity.Seat;
import com.cg.movie.entity.Show;

public interface MovieServiceInterface {
	public double totalCost(int seatId);
	


public List<Seat> reteriveu();

public List<Show> reterive();




}