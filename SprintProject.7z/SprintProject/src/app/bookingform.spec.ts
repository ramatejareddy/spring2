import { Bookingform } from './bookingform';

describe('Bookingform', () => {
  it('should create an instance', () => {
    expect(new Bookingform()).toBeTruthy();
  });
});
