import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CalculateTotalFare } from './calculateTotalFare';

@Injectable({
  providedIn: 'root'
})
export class BookingserviceService {
  private booking:CalculateTotalFare[]=[];

  constructor(private http:HttpClient) { }
  getTotalFare(fare:CalculateTotalFare):Observable<any>{
    let end=fare.seatId;
    let end1=fare.noOfSeats;
    
    return this.http.get("http://localhost:8089/seatfare/"+end+"/"+end1,{responseType:'text'});

  }
}
