import { Component, OnInit } from '@angular/core';

import { BookingserviceService } from '../bookingservice.service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';
import { CalculateTotalFare } from '../calculateTotalFare';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  fare:CalculateTotalFare= new CalculateTotalFare();
  msg:String;
  constructor(private bookingservice:BookingserviceService,private route:Router) { }

  ngOnInit() {
  }
  calculateFare(){
    console.log("calculate total fare");
    this.bookingservice.getTotalFare(this.fare).subscribe(data=>{this.msg=data});
      alert("Your data with "+this.msg+" Has been calculated");
   
    
  }

}
