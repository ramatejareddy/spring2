export class CalculateTotalFare{
    noOfSeats:number;
    seatId:number;
}