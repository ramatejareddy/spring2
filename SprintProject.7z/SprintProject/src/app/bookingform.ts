export class Bookingform {
    showId:number;
    tkts:number;
    userName:string;
    contact:string;
}

